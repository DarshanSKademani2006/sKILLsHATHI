@echo off
cd /d "%~dp0"

if not exist backend\venv\Scripts\python.exe (
    echo Creating virtual environment...
    py -m venv backend\venv
)

call backend\venv\Scripts\activate.bat

echo Installing required packages...
python -m pip install -r requirements.txt

echo.
echo Starting SkillSathi...
echo Open http://127.0.0.1:8000 in your browser
echo.

cd backend
python -m uvicorn main:app --reload

pause