SKILLSATHI - TEAM SETUP

1. Install Python on your computer.
   Make sure Python is added to PATH.

2. Extract the SkillSathi project folder.

3. Open the SkillSathi folder.

4. Double-click:
   run.bat

5. Wait until you see:
   Uvicorn running on http://127.0.0.1:8000

6. Open Chrome.

7. Go to:
   http://127.0.0.1:8000

8. The SkillSathi website will open.

IMPORTANT:
- Keep the black Command Prompt window open while using the website.
- Do not modify main.py, index.html, careers.json or other project files.
- To stop the website, close the Command Prompt window or press Ctrl+C.

PROJECT:
SkillSathi - AI-Enabled Career Counselling and Family Decision-Support Platform for Vocational Education