from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, ConfigDict, Field
from typing import Optional
from datetime import datetime
import json
import os
import re


# =========================================================
# APP SETUP
# =========================================================

app = FastAPI(
    title="SkillSathi",
    description="AI-Enabled Career Counselling and Family Decision-Support Platform",
    version="1.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# =========================================================
# FILE PATHS
# =========================================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

DATA_DIR = os.path.join(
    BASE_DIR,
    "data"
)

CAREERS_FILE = os.path.join(
    DATA_DIR,
    "careers.json"
)

SESSIONS_FILE = os.path.join(
    DATA_DIR,
    "sessions.json"
)

COUNSELLOR_FILE = os.path.join(
    DATA_DIR,
    "counsellor_requests.json"
)


# =========================================================
# JSON HELPERS
# =========================================================

def load_json(file_path, default):

    try:

        if not os.path.exists(file_path):
            return default

        with open(
            file_path,
            "r",
            encoding="utf-8"
        ) as file:

            return json.load(file)

    except Exception:

        return default


def save_json(file_path, data):

    os.makedirs(
        os.path.dirname(file_path),
        exist_ok=True
    )

    with open(
        file_path,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            data,
            file,
            indent=4,
            ensure_ascii=False
        )


# =========================================================
# LOAD DATA
# =========================================================

careers = load_json(
    CAREERS_FILE,
    []
)

sessions = load_json(
    SESSIONS_FILE,
    []
)

counsellor_requests = load_json(
    COUNSELLOR_FILE,
    []
)


# =========================================================
# PYDANTIC MODELS
# =========================================================

class StudentProfile(BaseModel):

    education: str = ""
    location: str = ""
    interest: str = ""
    skills: str = ""

    participant: str = "Student"

    concern: str = ""
    question: str = ""


class CounsellorRequest(BaseModel):

    model_config = ConfigDict(
        extra="allow"
    )

    student_name: str = ""

    education: str = ""
    location: str = ""
    interest: str = ""
    skills: str = ""

    career: str = ""
    recommendation: str = ""

    concern: str = ""

    concerns: list = Field(
        default_factory=list
    )

    question: str = ""

    parent_relationship: str = ""
    parent_question: str = ""

    participant: str = ""

    selected_concerns: list = Field(
        default_factory=list
    )

    profile: Optional[dict] = None
    student: Optional[dict] = None
    student_information: Optional[dict] = None

    family: Optional[dict] = None
    family_information: Optional[dict] = None


# =========================================================
# BASIC HELPERS
# =========================================================

def normalize_text(value):

    if value is None:
        return ""

    return str(value).strip().lower()


def get_career_name(career):

    if not isinstance(
        career,
        dict
    ):
        return ""

    return (
        career.get("career")
        or career.get("trade")
        or career.get("name")
        or ""
    )


def get_career_value(career, *keys):

    if not isinstance(
        career,
        dict
    ):
        return ""

    for key in keys:

        value = career.get(key)

        if (
            value is not None
            and str(value).strip()
        ):
            return value

    return ""


def tokenize(text):

    text = normalize_text(
        text
    )

    return set(

        word

        for word in re.findall(
            r"[a-zA-Z0-9]+",
            text
        )

        if len(word) > 1
    )


# =========================================================
# FLEXIBLE FIELD READER
# =========================================================

def first_value(*values):

    for value in values:

        if value is None:
            continue

        if isinstance(
            value,
            str
        ):

            if value.strip():
                return value

        elif isinstance(
            value,
            list
        ):

            if len(value) > 0:
                return value

        elif isinstance(
            value,
            dict
        ):

            if len(value) > 0:
                return value

        else:

            if str(value).strip():
                return value

    return ""


def get_nested_dict(data, *keys):

    if not isinstance(
        data,
        dict
    ):
        return {}

    for key in keys:

        value = data.get(key)

        if isinstance(
            value,
            dict
        ):
            return value

    return {}


# =========================================================
# CONCERN HELPERS
# =========================================================

def clean_concerns(value):

    if value is None:
        return []

    if isinstance(
        value,
        list
    ):

        result = []

        for item in value:

            if isinstance(
                item,
                dict
            ):

                item_value = first_value(

                    item.get("label"),
                    item.get("name"),
                    item.get("value"),
                    item.get("text"),
                    item.get("concern")
                )

                if item_value:

                    result.append(
                        str(item_value).strip()
                    )

            else:

                item_text = str(
                    item
                ).strip()

                if item_text:

                    result.append(
                        item_text
                    )

        return result

    if isinstance(
        value,
        str
    ):

        value = value.strip()

        if not value:
            return []

        if (
            value.startswith("[")
            and value.endswith("]")
        ):

            try:

                parsed = json.loads(
                    value
                )

                return clean_concerns(
                    parsed
                )

            except Exception:
                pass

        return [

            item.strip()

            for item in value.split(",")

            if item.strip()
        ]

    text = str(
        value
    ).strip()

    if text:
        return [text]

    return []


def find_concerns_from_sources(
    sources
):

    all_concerns = []

    for source in sources:

        if not isinstance(
            source,
            dict
        ):
            continue

        possible_values = [

            source.get("concerns"),
            source.get("selected_concerns"),
            source.get("selectedConcerns"),
            source.get("family_concerns"),
            source.get("familyConcerns"),
            source.get("parent_concerns"),
            source.get("parentConcerns"),
            source.get("concern_list"),
            source.get("concernList")
        ]

        for value in possible_values:

            cleaned = clean_concerns(
                value
            )

            for item in cleaned:

                if item not in all_concerns:

                    all_concerns.append(
                        item
                    )

    return all_concerns


# =========================================================
# QUESTION HELPERS
# =========================================================

def find_parent_question_from_sources(
    sources
):

    for source in sources:

        if not isinstance(
            source,
            dict
        ):
            continue

        question = first_value(

            source.get("parent_question"),
            source.get("parentQuestion"),
            source.get("question"),
            source.get("main_question"),
            source.get("mainQuestion"),
            source.get("parent_concern"),
            source.get("parentConcern"),
            source.get("main_concern"),
            source.get("mainConcern")
        )

        if question:

            return str(
                question
            ).strip()

    return ""


# =========================================================
# QUESTION / CONCERN UNDERSTANDING
# =========================================================

def understand_question(question):

    text = normalize_text(
        question
    )

    if not text:
        return "general"

    if any(
        word in text
        for word in [
            "job",
            "jobs",
            "employment",
            "work",
            "career opportunity",
            "job opportunity"
        ]
    ):
        return "job"

    if any(
        word in text
        for word in [
            "salary",
            "earning",
            "income",
            "pay",
            "money"
        ]
    ):
        return "salary"

    if any(
        word in text
        for word in [
            "security",
            "secure",
            "future",
            "stability"
        ]
    ):
        return "job_security"

    if any(
        word in text
        for word in [
            "higher education",
            "further education",
            "degree",
            "college",
            "study"
        ]
    ):
        return "further_education"

    if any(
        word in text
        for word in [
            "safe",
            "safety",
            "security for girls",
            "workplace safety"
        ]
    ):
        return "safety"

    if any(
        word in text
        for word in [
            "society",
            "social",
            "respect",
            "status",
            "perception"
        ]
    ):
        return "social_perception"

    if any(
        word in text
        for word in [
            "cost",
            "fee",
            "fees",
            "training cost",
            "expense"
        ]
    ):
        return "training_cost"

    return "general"


def extract_concern(profile):

    if profile.concern:

        return normalize_text(
            profile.concern
        )

    return understand_question(
        profile.question
    )


# =========================================================
# STUDENT DOMAIN DETECTION
# =========================================================

def detect_student_domains(text):

    text = normalize_text(
        text
    )

    domains = set()

    if any(
        word in text
        for word in [
            "ai",
            "artificial intelligence",
            "machine learning",
            "ml",
            "deep learning",
            "data science",
            "generative ai",
            "nlp"
        ]
    ):

        domains.add("ai")

    if any(
        word in text
        for word in [
            "computer",
            "computer science",
            "cse",
            "coding",
            "programming",
            "software",
            "python",
            "java"
        ]
    ):

        domains.add("computer")

    if any(
        word in text
        for word in [
            "electronics",
            "electronic",
            "circuit",
            "hardware",
            "embedded"
        ]
    ):

        domains.add("electronics")

    if any(
        word in text
        for word in [
            "mechanic",
            "mechanical",
            "machine",
            "automobile",
            "vehicle"
        ]
    ):

        domains.add("mechanical")

    if any(
        word in text
        for word in [
            "electric",
            "electrical",
            "wiring",
            "power"
        ]
    ):

        domains.add("electrical")

    if any(
        word in text
        for word in [
            "fashion",
            "garment",
            "clothing",
            "textile"
        ]
    ):

        domains.add("fashion")

    return domains


# =========================================================
# CAREER MATCHING
# =========================================================

def career_matches(profile):

    results = []

    interest_text = normalize_text(
        profile.interest
    )

    skills_text = normalize_text(
        profile.skills
    )

    education_text = normalize_text(
        profile.education
    )

    # -----------------------------------------------------
    # Interest is the primary signal.
    # Skills and education are used only after an interest
    # match has been found. This prevents common skills such
    # as Python or Java from overriding an unrelated interest.
    # -----------------------------------------------------

    interest_tokens = tokenize(
        interest_text
    )

    skills_tokens = tokenize(
        skills_text
    )

    candidate_results = []

    for career in careers:

        career_name = get_career_name(
            career
        )

        career_keywords = career.get(
            "keywords",
            []
        )

        if not isinstance(
            career_keywords,
            list
        ):
            career_keywords = []

        keyword_text = " ".join(
            str(keyword)
            for keyword in career_keywords
        )

        job_roles = career.get(
            "job_roles",
            []
        )

        if not isinstance(
            job_roles,
            list
        ):
            job_roles = []

        progression = career.get(
            "progression",
            []
        )

        if not isinstance(
            progression,
            list
        ):
            progression = []

        career_text = " ".join(
            [
                str(career_name),
                str(career.get("trade", "")),
                str(career.get("career_area", "")),
                str(career.get("training", "")),
                keyword_text,
                " ".join(
                    str(x)
                    for x in job_roles
                ),
                str(
                    career.get(
                        "what_you_learn",
                        ""
                    )
                ),
                " ".join(
                    str(x)
                    for x in progression
                )
            ]
        )

        career_text = normalize_text(
            career_text
        )

        career_tokens = tokenize(
            career_text
        )

        career_domains = detect_student_domains(
            career_text
        )

        interest_domains = detect_student_domains(
            interest_text
        )

        # -------------------------------------------------
        # 1. INTEREST SCORE
        # -------------------------------------------------

        interest_word_matches = len(
            interest_tokens.intersection(
                career_tokens
            )
        )

        interest_keyword_matches = 0

        for keyword in career_keywords:

            keyword_normalized = normalize_text(
                keyword
            )

            if not keyword_normalized:
                continue

            if keyword_normalized in interest_text:
                interest_keyword_matches += 1

        interest_domain_matches = len(
            interest_domains.intersection(
                career_domains
            )
        )

        # A direct career-name/trade match is especially strong.
        career_name_normalized = normalize_text(
            career_name
        )

        direct_name_match = (
            bool(career_name_normalized)
            and (
                career_name_normalized in interest_text
                or interest_text in career_name_normalized
            )
        )

        interest_score = (
            interest_word_matches * 20
            + interest_keyword_matches * 30
            + interest_domain_matches * 20
        )

        if direct_name_match:
            interest_score += 60

        # -------------------------------------------------
        # IMPORTANT:
        # If the user's interest has no meaningful relationship
        # with this career, do not allow skills/education to
        # create a false recommendation.
        # -------------------------------------------------

        if interest_score <= 0:
            continue

        # -------------------------------------------------
        # 2. EDUCATION SUPPORT
        # -------------------------------------------------

        eligibility = normalize_text(
            str(
                career.get(
                    "eligibility",
                    ""
                )
            )
        )

        education_score = 0

        if education_text:

            if education_text in eligibility:
                education_score = 20

            elif (
                education_text == "10th pass"
                and "10th" in eligibility
            ):
                education_score = 20

            elif (
                education_text == "12th pass"
                and "12th" in eligibility
            ):
                education_score = 20

            elif (
                "diploma" in education_text
                and (
                    "diploma" in eligibility
                    or "10th" in eligibility
                    or "12th" in eligibility
                )
            ):
                education_score = 15

            elif (
                "degree" in education_text
                and (
                    "degree" in eligibility
                    or "graduate" in eligibility
                    or "12th" in eligibility
                )
            ):
                education_score = 15

        # -------------------------------------------------
        # 3. SKILLS SUPPORT
        # -------------------------------------------------

        skill_word_matches = len(
            skills_tokens.intersection(
                career_tokens
            )
        )

        skill_keyword_matches = 0

        for keyword in career_keywords:

            keyword_normalized = normalize_text(
                keyword
            )

            if not keyword_normalized:
                continue

            if keyword_normalized in skills_text:
                skill_keyword_matches += 1

        skill_score = min(
            20,
            (skill_word_matches * 3)
            + (skill_keyword_matches * 5)
        )

        # -------------------------------------------------
        # FINAL SCORE
        # Interest is always the dominant component.
        # -------------------------------------------------

        score = (
            interest_score
            + education_score
            + skill_score
        )

        candidate_results.append(
            {
                "career": career,
                "score": score,
                "interest_score": interest_score
            }
        )

    # -----------------------------------------------------
    # If there is no meaningful interest match, return no
    # recommendation instead of selecting a career merely
    # because the learner has common technical skills.
    # -----------------------------------------------------

    if not candidate_results:
        return []

    candidate_results.sort(
        key=lambda item: (
            item["interest_score"],
            item["score"]
        ),
        reverse=True
    )

    # Keep the existing API response shape.
    for item in candidate_results:

        results.append(
            {
                "career": item["career"],
                "score": item["score"]
            }
        )

    return results


# =========================================================
# COUNSELLING GENERATION
# =========================================================

def generate_counselling(
    profile,
    career
):

    career_name = get_career_name(
        career
    )

    if not career_name:

        career_name = "this career"

    interest = (
        profile.interest.strip()
        or "the selected field"
    )

    skills = (
        profile.skills.strip()
        or "your current skills"
    )

    education = (
        profile.education.strip()
        or "your current education level"
    )

    location = (
        profile.location.strip()
        or "your location"
    )

    career_area = get_career_value(
        career,
        "career_area",
        "area",
        "sector"
    )

    training = get_career_value(
        career,
        "training",
        "course",
        "training_name"
    )

    eligibility = get_career_value(
        career,
        "eligibility",
        "entry_requirement"
    )

    what_you_learn = get_career_value(
        career,
        "what_you_learn",
        "skills",
        "training_content"
    )

    duration = get_career_value(
        career,
        "duration",
        "training_duration"
    )

    nsqf_level = get_career_value(
        career,
        "nsqf_level",
        "level"
    )

    source = get_career_value(
        career,
        "source"
    )

    progression = career.get(
        "progression",
        []
    )

    if not isinstance(
        progression,
        list
    ):

        progression = []

    job_roles = career.get(
        "job_roles",
        []
    )

    if not isinstance(
        job_roles,
        list
    ):

        job_roles = []

    answer_parts = []

    answer_parts.append(
        f"Based on your stated interest, education and current skills, "
        f"{career_name} is a relevant career option to explore."
    )

    answer_parts.append(
        f"Your stated interest is {interest}. "
        f"The recommendation is based primarily on the relationship "
        f"between this interest and the career information in the "
        f"SkillSathi verified career dataset."
    )

    answer_parts.append(
        f"Your current skills in {skills} can provide a useful "
        f"starting point for this training."
    )

    answer_parts.append(
        f"Your current education level is {education}. "
        f"The learner should also verify the latest eligibility "
        f"requirements with the training institute before admission."
    )

    answer_parts.append(
        "The decision should be based on the learner's interest, "
        "skills, training requirements, employment opportunities "
        "and long-term career growth."
    )

    if career_area:

        answer_parts.append(
            f"Career area: {career_area}."
        )

    if training:

        answer_parts.append(
            f"Training focus: {training}."
        )

    if eligibility:

        answer_parts.append(
            f"Eligibility information: {eligibility}."
        )

    if what_you_learn:

        answer_parts.append(
            f"What the learner can develop: {what_you_learn}."
        )

    if duration:

        answer_parts.append(
            f"Training duration: {duration}."
        )

    if nsqf_level:

        answer_parts.append(
            f"NSQF level: {nsqf_level}."
        )

    if job_roles:

        answer_parts.append(
            "Possible job roles include: "
            + ", ".join(
                str(role)
                for role in job_roles
            )
            + "."
        )

    if progression:

        answer_parts.append(
            "Possible career progression includes: "
            + ", ".join(
                str(item)
                for item in progression
            )
            + "."
        )

    if location:

        answer_parts.append(
            f"For a learner in {location}, it is useful to check "
            "nearby training institutes, apprenticeship opportunities "
            "and current employer demand before making the final decision."
        )

    if source:

        answer_parts.append(
            f"Verified source: {source}."
        )

    answer_parts.append(
        "If the family still has concerns, SkillSathi can connect "
        "the learner or parent with a human counsellor for "
        "additional guidance."
    )

    return " ".join(
        answer_parts
    )


# =========================================================
# HOME PAGE
# =========================================================

@app.get("/")
def home():

    frontend_file = os.path.join(
        BASE_DIR,
        "..",
        "frontend",
        "index.html"
    )

    frontend_file = os.path.abspath(
        frontend_file
    )

    if os.path.exists(
        frontend_file
    ):

        return FileResponse(
            frontend_file
        )

    return {
        "message":
            "SkillSathi backend is running."
    }


# =========================================================
# CAREERS API
# =========================================================

@app.get("/careers")
def get_careers():

    return careers


# =========================================================
# PROFILE / COUNSELLING
# =========================================================

@app.post("/profile")
def create_profile(
    profile: StudentProfile
):

    matches = career_matches(
        profile
    )

    if not matches:

        return {
            "success": True,
            "recommendation": "",
            "matches": [],
            "career": None,
            "concern": extract_concern(profile),
            "counselling_answer": (
                "No strong career match was found for the learner's stated interest "
                "in the current SkillSathi career database. The system will not "
                "force a recommendation based only on general skills. Please "
                "consider adding a more specific career interest or speak with "
                "a human counsellor for further guidance."
            )
        }

    best_match = matches[0]["career"]

    recommendation = get_career_name(
        best_match
    )

    counselling_answer = generate_counselling(
        profile,
        best_match
    )

    concern = extract_concern(
        profile
    )

    session_id = len(
        sessions
    ) + 1

    session = {

        "session_id":
            session_id,

        "timestamp":
            datetime.now().isoformat(),

        "profile":
            profile.model_dump(),

        "recommendation":
            recommendation,

        "concern":
            concern,

        "counselling_answer":
            counselling_answer,

        "career":
            best_match,

        "matches":
            [
                {
                    "career":
                        get_career_name(
                            item["career"]
                        ),

                    "score":
                        item["score"]
                }

                for item in matches[:5]
            ]
    }

    sessions.append(
        session
    )

    save_json(
        SESSIONS_FILE,
        sessions
    )

    return {

        "session_id":
            session_id,

        "recommendation":
            recommendation,

        "career":
            best_match,

        "counselling_answer":
            counselling_answer,

        "concern":
            concern,

        "matches":
            [
                {
                    "career":
                        item["career"],

                    "score":
                        item["score"]
                }

                for item in matches[:5]
            ]
    }


# =========================================================
# RECOMMENDATION RECOVERY
# =========================================================

def recover_recommendation(
    session
):

    if not isinstance(
        session,
        dict
    ):

        return ""

    recommendation = session.get(
        "recommendation",
        ""
    )

    if recommendation:

        return str(
            recommendation
        ).strip()

    recommended_career = session.get(
        "recommended_career",
        ""
    )

    if recommended_career:

        return str(
            recommended_career
        ).strip()

    career_data = session.get(
        "career"
    )

    if isinstance(
        career_data,
        dict
    ):

        career_name = get_career_name(
            career_data
        )

        if career_name:

            return career_name

    profile_data = session.get(
        "profile"
    )

    if isinstance(
        profile_data,
        dict
    ):

        try:

            profile = StudentProfile(
                **profile_data
            )

            matches = career_matches(
                profile
            )

            if matches:

                career_name = get_career_name(
                    matches[0]["career"]
                )

                if career_name:

                    return career_name

        except Exception:
            pass

    try:

        parent_profile = StudentProfile(

            education=session.get(
                "education",
                ""
            ),

            location=session.get(
                "location",
                ""
            ),

            interest=session.get(
                "interest",
                ""
            ),

            skills=session.get(
                "skills",
                ""
            ),

            participant=session.get(
                "parent_relationship",
                "Parent"
            ),

            concern=session.get(
                "concern",
                ""
            ),

            question=session.get(
                "parent_question",
                ""
            )
        )

        matches = career_matches(
            parent_profile
        )

        if matches:

            career_name = get_career_name(
                matches[0]["career"]
            )

            if career_name:

                return career_name

    except Exception:
        pass

    counselling_answer = str(
        session.get(
            "counselling_answer",
            ""
        )
    )

    training_match = re.search(
        r"Training focus:\s*(.+?)(?:\.|$)",
        counselling_answer,
        re.IGNORECASE
    )

    if training_match:

        training_name = normalize_text(
            training_match.group(1)
        )

        for career in careers:

            training = normalize_text(
                career.get(
                    "training",
                    ""
                )
            )

            if training and (
                training == training_name
                or training_name in training
                or training in training_name
            ):

                career_name = get_career_name(
                    career
                )

                if career_name:

                    return career_name

    return ""


# =========================================================
# NORMALIZE COUNSELLOR REQUEST
# =========================================================

def normalize_counsellor_payload(
    request
):

    data = request.model_dump()

    nested_student = {}
    nested_family = {}

    nested_sources = []

    nested_sources.append(
        data
    )

    for source in [

        data.get("profile"),
        data.get("student"),
        data.get("student_information"),
        data.get("studentInfo"),
        data.get("student_profile"),
        data.get("studentProfile")
    ]:

        if isinstance(
            source,
            dict
        ):

            nested_student.update(
                source
            )

            nested_sources.append(
                source
            )

    for source in [

        data.get("family"),
        data.get("family_information"),
        data.get("familyInfo"),
        data.get("family_profile"),
        data.get("familyProfile"),
        data.get("parent"),
        data.get("parent_information"),
        data.get("parentInfo")
    ]:

        if isinstance(
            source,
            dict
        ):

            nested_family.update(
                source
            )

            nested_sources.append(
                source
            )

    education = first_value(

        data.get("education"),

        nested_student.get("education"),

        nested_student.get("highest_education"),

        nested_student.get("highestEducation")
    )

    location = first_value(

        data.get("location"),

        nested_student.get("location")
    )

    interest = first_value(

        data.get("interest"),

        nested_student.get("interest")
    )

    skills = first_value(

        data.get("skills"),

        nested_student.get("skills")
    )

    student_name = first_value(

        data.get("student_name"),

        data.get("studentName"),

        nested_student.get("student_name"),

        nested_student.get("studentName"),

        nested_student.get("name")
    )

    recommendation = first_value(

        data.get("recommendation"),

        data.get("career"),

        data.get("recommended_career"),

        data.get("recommendedCareer"),

        nested_student.get("recommendation"),

        nested_student.get("career"),

        nested_student.get("recommended_career"),

        nested_student.get("recommendedCareer")
    )

    parent_relationship = first_value(

        data.get("parent_relationship"),

        data.get("parentRelationship"),

        data.get("relationship"),

        data.get("participant"),

        nested_family.get("parent_relationship"),

        nested_family.get("parentRelationship"),

        nested_family.get("relationship"),

        nested_family.get("participant"),

        "Parent"
    )

    concerns = find_concerns_from_sources(
        nested_sources
    )

    if not concerns:

        concerns = clean_concerns(

            first_value(

                data.get("concerns"),

                data.get("selected_concerns")
            )
        )

    parent_question = find_parent_question_from_sources(
        nested_sources
    )

    if not parent_question:

        parent_question = str(
            first_value(

                data.get("parent_question"),

                data.get("question"),

                data.get("main_question"),

                data.get("main_concern")
            )
            or ""
        ).strip()

    concern = first_value(

        data.get("concern"),

        nested_family.get("concern"),

        nested_family.get("selected_concern")
    )

    if not concern and concerns:

        concern = concerns[0]

    if not concern:

        concern = understand_question(
            parent_question
        )

    question = first_value(

        data.get("question"),

        data.get("main_question"),

        data.get("mainQuestion"),

        parent_question
    )

    return {

        "student_name":
            str(
                student_name or ""
            ).strip(),

        "education":
            str(
                education or ""
            ).strip(),

        "location":
            str(
                location or ""
            ).strip(),

        "interest":
            str(
                interest or ""
            ).strip(),

        "skills":
            str(
                skills or ""
            ).strip(),

        "concerns":
            concerns,

        "recommendation":
            str(
                recommendation or ""
            ).strip(),

        "parent_relationship":
            str(
                parent_relationship or "Parent"
            ).strip(),

        "parent_question":
            str(
                parent_question or ""
            ).strip(),

        "concern":
            str(
                concern or "general"
            ).strip(),

        "question":
            str(
                question or ""
            ).strip()
    }


# =========================================================
# COUNSELLOR REQUEST
# =========================================================

@app.post("/counsellor-request")
def create_counsellor_request(
    request: CounsellorRequest
):

    request_data = normalize_counsellor_payload(
        request
    )

    recommendation = request_data.get(
        "recommendation",
        ""
    )

    if (
        not recommendation
        or recommendation.strip().lower()
        in [
            "not available",
            "none",
            "n/a"
        ]
    ):

        try:

            profile = StudentProfile(

                education=request_data.get(
                    "education",
                    ""
                ),

                location=request_data.get(
                    "location",
                    ""
                ),

                interest=request_data.get(
                    "interest",
                    ""
                ),

                skills=request_data.get(
                    "skills",
                    ""
                ),

                participant=request_data.get(
                    "parent_relationship",
                    "Parent"
                ),

                concern=request_data.get(
                    "concern",
                    ""
                ),

                question=request_data.get(
                    "parent_question",
                    ""
                )
            )

            matches = career_matches(
                profile
            )

            if matches:

                recommendation = get_career_name(
                    matches[0]["career"]
                )

        except Exception:

            recommendation = ""

    if not recommendation:

        recommendation = "Not available"

    request_id_number = (
        len(counsellor_requests) + 1
    )

    request_id = (
        f"SS-{request_id_number:04d}"
    )

    final_concerns = clean_concerns(

        request_data.get(
            "concerns",
            []
        )
    )

    final_parent_question = str(

        request_data.get(
            "parent_question",
            ""
        ) or ""

    ).strip()

    new_request = {

        "request_id":
            request_id,

        "student_name":
            request_data.get(
                "student_name",
                ""
            ),

        "education":
            request_data.get(
                "education",
                ""
            ),

        "location":
            request_data.get(
                "location",
                ""
            ),

        "interest":
            request_data.get(
                "interest",
                ""
            ),

        "skills":
            request_data.get(
                "skills",
                ""
            ),

        "concerns":
            final_concerns,

        "selected_concerns":
            final_concerns,

        "recommendation":
            recommendation,

        "recommended_career":
            recommendation,

        "parent_relationship":
            request_data.get(
                "parent_relationship",
                "Parent"
            ),

        "participant":
            request_data.get(
                "parent_relationship",
                "Parent"
            ),

        "parent_question":
            final_parent_question,

        "question":
            final_parent_question,

        "concern":
            request_data.get(
                "concern",
                "general"
            ),

        "status":
            "Pending",

        "requested_at":
            datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S"
            )
    }

    counsellor_requests.append(
        new_request
    )

    save_json(
        COUNSELLOR_FILE,
        counsellor_requests
    )

    return {

        "success":
            True,

        "message":
            "Counsellor request submitted successfully.",

        "request_id":
            request_id,

        "recommendation":
            recommendation,

        "status":
            "Pending",

        "request":
            new_request
    }


# =========================================================
# GET COUNSELLOR REQUESTS
# =========================================================

@app.get("/counsellor-requests")
def get_counsellor_requests():

    return counsellor_requests


# =========================================================
# REVIEW COUNSELLOR REQUEST
# =========================================================

@app.post(
    "/counsellor-request/{request_id}/review"
)
def review_counsellor_request(
    request_id: str
):

    for request in counsellor_requests:

        if request.get(
            "request_id"
        ) == request_id:

            request["status"] = "Reviewed"

            request["reviewed_at"] = (
                datetime.now().strftime(
                    "%Y-%m-%d %H:%M:%S"
                )
            )

            save_json(
                COUNSELLOR_FILE,
                counsellor_requests
            )

            return {

                "success":
                    True,

                "message":
                    "Counsellor request reviewed successfully.",

                "status":
                    "Reviewed",

                "request":
                    request
            }

    raise HTTPException(
        status_code=404,
        detail="Counsellor request not found."
    )


# =========================================================
# EXTRACT SESSION PROFILE
# =========================================================

def get_session_profile(
    session
):

    if not isinstance(
        session,
        dict
    ):

        return {}

    profile = session.get(
        "profile"
    )

    if isinstance(
        profile,
        dict
    ):

        return profile

    for key in [
        "student",
        "student_information"
    ]:

        profile = session.get(
            key
        )

        if isinstance(
            profile,
            dict
        ):

            return profile

    return {

        "education":
            session.get(
                "education",
                ""
            ),

        "location":
            session.get(
                "location",
                ""
            ),

        "interest":
            session.get(
                "interest",
                ""
            ),

        "skills":
            session.get(
                "skills",
                ""
            ),

        "participant":
            session.get(
                "participant",
                session.get(
                    "parent_relationship",
                    "Student"
                )
            ),

        "concern":
            session.get(
                "concern",
                ""
            ),

        "question":
            session.get(
                "question",
                session.get(
                    "parent_question",
                    ""
                )
            )
    }


# =========================================================
# DASHBOARD DATA
# =========================================================

@app.get("/dashboard-data")
def dashboard_data():

    total_sessions = len(
        sessions
    )

    interest_counts = {}
    concern_counts = {}
    location_counts = {}

    total_recommendations = 0
    total_concerns = 0

    for session in sessions:

        if not isinstance(
            session,
            dict
        ):

            continue

        profile = get_session_profile(
            session
        )

        interest = normalize_text(

            first_value(

                profile.get("interest"),

                session.get("interest")
            )
        )

        if not interest:

            interest = "Unknown"

        interest_counts[interest] = (

            interest_counts.get(
                interest,
                0
            ) + 1
        )

        location = normalize_text(

            first_value(

                profile.get("location"),

                session.get("location")
            )
        )

        if not location:

            location = "Unknown"

        location_counts[location] = (

            location_counts.get(
                location,
                0
            ) + 1
        )

        concern = normalize_text(

            first_value(

                session.get("concern"),

                profile.get("concern")
            )
        )

        if not concern:

            concern = understand_question(

                first_value(

                    profile.get("question"),

                    session.get("question"),

                    session.get("parent_question")
                )
            )

        if not concern:

            concern = "general"

        concern_counts[concern] = (

            concern_counts.get(
                concern,
                0
            ) + 1
        )

        total_concerns += 1

        recommendation = recover_recommendation(
            session
        )

        if recommendation:

            total_recommendations += 1

    recent_cases = []

    for session in reversed(
        sessions[-10:]
    ):

        if not isinstance(
            session,
            dict
        ):

            continue

        profile = get_session_profile(
            session
        )

        recommendation = recover_recommendation(
            session
        )

        concern = normalize_text(

            first_value(

                session.get("concern"),

                profile.get("concern")
            )
        )

        if not concern:

            concern = understand_question(

                first_value(

                    profile.get("question"),

                    session.get("question"),

                    session.get("parent_question")
                )
            )

        if not concern:

            concern = "general"

        case = dict(
            session
        )

        case["profile"] = {

            "education":
                first_value(

                    profile.get("education"),

                    session.get("education")
                ),

            "location":
                first_value(

                    profile.get("location"),

                    session.get("location")
                ),

            "interest":
                first_value(

                    profile.get("interest"),

                    session.get("interest")
                ),

            "skills":
                first_value(

                    profile.get("skills"),

                    session.get("skills")
                ),

            "participant":
                first_value(

                    profile.get("participant"),

                    session.get("participant"),

                    session.get("parent_relationship")
                ),

            "concern":
                concern,

            "question":
                first_value(

                    profile.get("question"),

                    session.get("question"),

                    session.get("parent_question")
                )
        }

        case["recommendation"] = (
            recommendation
        )

        case["concern"] = concern

        recent_cases.append(
            case
        )

    return {

        "total_sessions":
            total_sessions,

        "total_recommendations":
            total_recommendations,

        "total_concerns":
            total_concerns,

        "total_counsellor_requests":
            len(
                counsellor_requests
            ),

        "career_interests":
            interest_counts,

        "concerns":
            concern_counts,

        "locations":
            location_counts,

        "interest_counts":
            interest_counts,

        "concern_counts":
            concern_counts,

        "location_counts":
            location_counts,

        "recent_cases":
            recent_cases,

        "counsellor_requests":
            counsellor_requests
    }


# =========================================================
# DASHBOARD PAGE
# =========================================================

@app.get("/dashboard")
def dashboard():

    dashboard_file = os.path.join(

        BASE_DIR,
        "..",
        "frontend",
        "dashboard.html"
    )

    dashboard_file = os.path.abspath(
        dashboard_file
    )

    if os.path.exists(
        dashboard_file
    ):

        return FileResponse(
            dashboard_file
        )

    return {
        "message":
            "Dashboard file not found."
    }


# =========================================================
# HEALTH CHECK
# =========================================================

@app.get("/health")
def health():

    return {

        "status":
            "ok",

        "service":
            "SkillSathi"
    }